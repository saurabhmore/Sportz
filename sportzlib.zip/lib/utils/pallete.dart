import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

TextStyle kTitleText = TextStyle(
  fontSize: 18.sp,
  fontWeight: FontWeight.bold,
  color: Colors.black,
);

TextStyle kNormalText = TextStyle(
  fontSize: 14.sp,
  //fontWeight: FontWeight.bold,
  color: Colors.black,
);

TextStyle kNormalBoldText = TextStyle(
  fontSize: 14.sp,
  fontWeight: FontWeight.bold,
  color: Colors.black,
);
